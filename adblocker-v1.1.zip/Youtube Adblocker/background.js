chrome.runtime.onInstalled.addListener(() => {
  console.log("Ad blocker installed");
});