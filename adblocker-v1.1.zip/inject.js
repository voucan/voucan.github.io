(function () {
    let adblockEnabled = true;
    let showButton = false;
    const button = document.createElement("button");

    button.innerText = "Manually Skip Ad";
    button.style.position = "fixed";
    button.style.bottom = "20px";
    button.style.right = "20px";
    button.style.padding = "12px 24px";
    button.style.border = "none";
    button.style.borderRadius = "8px";
    button.style.fontSize = "16px";
    button.style.cursor = "pointer";
    button.style.zIndex = "9999";
    button.style.transition = "all 0.3s ease-in-out";
    button.style.boxShadow = "0 4px 10px rgba(0, 0, 0, 0.2)";
    button.style.fontFamily = "Arial, sans-serif";

    const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    button.style.backgroundColor = isDarkMode ? "#333" : "#FFF";
    button.style.color = isDarkMode ? "#FFF" : "#000";

    button.onmouseover = () => {
        button.style.backgroundColor = isDarkMode ? "#555" : "#f1f1f1";
    };

    button.onmouseout = () => {
        button.style.backgroundColor = isDarkMode ? "#333" : "#FFF";
    };

    function skipAd() {
        if (!adblockEnabled) return;

        const videoAds = document.querySelector(".video-ads");
        if (videoAds && videoAds.innerHTML !== "") {
            let banner = false;
            document.querySelectorAll(".ytp-ad-overlay-close-button").forEach(button => {
                button.click();
                banner = true;
            });
            if (!banner) {
                const video = document.querySelector(".html5-main-video");
                if (video) {
                    video.currentTime = video.duration;
                }
                const skipButton = document.querySelector(".ytp-ad-skip-button, .ytp-ad-skip-button-modern");
                if (skipButton) {
                    skipButton.click();
                }
            }
        }
    }

    function removeAds() {
        document.querySelectorAll('img.ytwAdImageViewModelHostImage')
            .forEach(img => { img.src = "https://i.ibb.co/VcRbwSnL/download.png"; });

        document.querySelectorAll('.ytwFeedAdMetadataViewModelHostMetadata, .ytwAdButtonViewModelHost, .ad-inline-playback-metadata, .ytwAdAvatarLockupViewModelHostTextsStyleCompact, .style-scope.ytd-promoted-video-renderer, .style-scope.ytd-in-feed-ad-layout-renderer')
            .forEach(element => { element.remove(); });

        document.querySelectorAll('[class*="style-scope ytd-ad-inline-playback-meta-block"], [class*="masthead-ad"]')
            .forEach(element => { element.remove(); });

        const clickableAdComponent = document.querySelector(".ytwAdImageViewModelHostIsClickableAdComponent");
        if (clickableAdComponent) {
            let parent1 = clickableAdComponent.parentElement;
            let parent2 = parent1 ? parent1.parentElement : null;

            if (parent2) { parent2.remove(); }
            if (parent1) { parent1.remove(); }
        }
    }

    if (showButton) {
        button.onclick = skipAd;
        document.body.appendChild(button);
    }

    let adblockInterval = setInterval(() => {
        if (adblockEnabled) {
            skipAd();
            removeAds();
        }
    }, 100);

    window.adblockCheck = function () {
        console.log(adblockEnabled ? "Adblocker Status - Active" : "Adblocker Status - Inactive");
    };

    window.adblockToggle = function () {
        adblockEnabled = !adblockEnabled;
        console.log(`Adblock ${adblockEnabled ? "Enabled" : "Disabled"}`);
        if (adblockEnabled) {
            adblockInterval = setInterval(() => {
                skipAd();
                removeAds();
            }, 100);
        } else {
            clearInterval(adblockInterval);
        }
    };

    window.adblockBToggle = function () {
        showButton = !showButton;
        console.log(`Adblock Button ${showButton ? "Visible" : "Hidden"}`);
        if (showButton) {
            document.body.appendChild(button);
        } else {
            if (document.body.contains(button)) {
                document.body.removeChild(button);
            }
        }
    };

    console.log("YT Ad Blocker script injected.");
})();